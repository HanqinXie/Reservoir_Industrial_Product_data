# SPDX-FileCopyrightText: PyPSA Contributors
#
# SPDX-License-Identifier: MIT

import copy
import pickle
import sys
import warnings
from pathlib import Path

import linopy
import numpy as np
import pandas as pd
import pytest

import pypsa

rng = np.random.default_rng()


def swap_df_index(df, axis=0):
    df_swapped = df.copy()

    if axis == 0:
        # Swap rows: swap row 0 with row 1
        df_swapped.iloc[[0, 1]] = df_swapped.iloc[[1, 0]].values
    elif axis == 1:
        # Swap columns: swap column 0 with column 1
        df_swapped.iloc[:, [0, 1]] = df_swapped.iloc[:, [1, 0]].values
    else:
        raise ValueError(
            f"Invalid axis {axis}. Allowed values are 0 (rows) and 1 (columns)."
        )

    return df_swapped


@pytest.fixture
def n_5bus():
    # Set up empty network with 5 buses.
    n = pypsa.Network()
    n.add("Bus", [f"bus_{i} " for i in range(5)])
    return n


@pytest.fixture
def n_5bus_7sn():
    # Set up empty network with 5 buses and 7 snapshots.
    n = pypsa.Network()
    n_buses = 5
    n_snapshots = 7
    n.add("Bus", [f"bus_{i} " for i in range(n_buses)])
    n.set_snapshots(range(n_snapshots))
    return n


def test_remove(ac_dc_network):
    """
    GIVEN   the AC DC exemplary pypsa network.

    WHEN    two components of Generator are removed with remove

    THEN    the generator dataframe and the time-dependent generator
    dataframe should not contain the removed elements.
    """
    n = ac_dc_network

    generators = {"Manchester Wind", "Frankfurt Wind"}

    n.remove("Generator", generators)

    assert not generators.issubset(n.c.generators.static.index)
    assert not generators.issubset(n.c.generators.dynamic.p_max_pu.columns)


def test_remove_with_unnamed_dynamic_columns(ac_dc_network):
    n = ac_dc_network
    c = n.c.generators
    c.dynamic.p_max_pu = c.dynamic.p_max_pu.rename_axis(columns=None)

    n.remove("Generator", "Manchester Wind")

    assert "Manchester Wind" not in c.dynamic.p_max_pu.columns


def test_remove_stochastic(ac_dc_stochastic):
    """Components are removed from all scenarios (#1955)."""
    n = ac_dc_stochastic
    c = n.c.generators

    generators = ["Manchester Wind", "Frankfurt Wind"]

    n.remove("Generator", generators)
    n.remove("GlobalConstraint", "co2_limit")

    assert not c.static.index.isin(generators, level="name").any()
    assert list(c.dynamic.p_max_pu.columns) == [
        ("low", "Norway Wind"),
        ("high", "Norway Wind"),
    ]
    assert n.c.global_constraints.static.empty

    with pytest.raises(KeyError):
        n.remove("Generator", "Manchester Wind")


def test_remove_misspelled_component(ac_dc_network):
    """
    GIVEN   the AC DC exemplary pypsa network.

    WHEN    a misspelled component is removed with remove

    THEN    the function should not change anything in the Line
    component dataframe and an error should be logged.
    """
    n = ac_dc_network
    misspelled_component = "Liness"
    with pytest.raises(AttributeError, match=f"components '{misspelled_component}'"):
        n.remove(misspelled_component, ["0", "1"])


def test_add_misspelled_component(n_5bus):
    """
    GIVEN   an empty PyPSA network with 5 buses.

    WHEN    multiple components of a misspelled component are added

    THEN    the function should not change anything and an error should
    be logged.
    """
    misspelled_component = "Generatro"
    with pytest.raises(AttributeError, match=f"components '{misspelled_component}'"):
        n_5bus.add(
            misspelled_component,
            ["g_1", "g_2"],
            bus=["bus_1", "bus_2"],
        )


def test_add_duplicated_names(n_5bus):
    """
    GIVEN   an empty PyPSA network with 5 buses.

    WHEN    adding generators with the same name

    THEN    the function should fail and an error should be logged.
    """
    with pytest.raises(ValueError, match="must be unique"):
        n_5bus.add(
            "Generator",
            ["g_1", "g_1"],
            bus=["bus_1", "bus_2"],
        )


@pytest.mark.parametrize("slicer", [0, slice(0, 1), slice(None, None)])
def test_add_static(n_5bus, slicer):
    buses = n_5bus.c.buses.static.index[slicer]

    load_names = "load_" + buses

    n_5bus.add("Load", load_names, bus=buses, p_set=3)

    if slicer == 0:
        load_names = pd.Index([load_names])

    assert len(n_5bus.c.loads.static) == len(load_names)
    assert n_5bus.c.loads.static.index.name == "name"
    assert n_5bus.c.loads.static.index.equals(load_names)
    assert (n_5bus.c.loads.static.bus == buses).all()
    assert (n_5bus.c.loads.static.p_set == 3).all()

    if slicer == slice(None, None):
        # Test different names shape
        with pytest.raises(ValueError, match="for each component name."):
            n_5bus.add("Load", load_names[1:] + "_a", bus=buses)


@pytest.mark.parametrize("slicer", [slice(0, 1), slice(None, None)])
def test_add_static_with_index(n_5bus, slicer):
    buses = n_5bus.c.buses.static.index[slicer]

    load_names = "load_" + buses
    buses = pd.Series(buses, index=load_names)

    n_5bus.add(
        "Load",
        load_names,
        bus=buses,
        p_set=3,
    )

    assert len(n_5bus.c.loads.static) == len(load_names)
    assert n_5bus.c.loads.static.index.name == "name"
    assert n_5bus.c.loads.static.index.equals(load_names)
    assert (n_5bus.c.loads.static.bus == buses).all()
    assert (n_5bus.c.loads.static.p_set == 3).all()

    if len(buses) > 1:
        # Test unaligned names index
        with pytest.raises(ValueError, match="index which does not align"):
            n_5bus.add("Load", load_names + "_a", bus=swap_df_index(buses))


def test_add_varying_single(n_5bus_7sn):
    buses = n_5bus_7sn.c.buses.static.index

    # Add load component at every bus with time-dependent attribute p_set.
    p_set = rng.random(size=(len(n_5bus_7sn.snapshots)))
    n_5bus_7sn.add(
        "Load",
        "load_1",
        bus=buses[0],
        p_set=p_set,
    )

    assert len(n_5bus_7sn.c.loads.static) == 1
    assert n_5bus_7sn.c.loads.static.index.name == "name"
    assert (n_5bus_7sn.c.loads.static.index == "load_1").all()
    assert (n_5bus_7sn.c.loads.static.bus == buses[0]).all()
    assert (p_set == n_5bus_7sn.c.loads.dynamic.p_set.T).all().all()
    assert (
        n_5bus_7sn.c.loads.static.p_set == 0
    ).all()  # Assert that default value is set

    # Test different snapshots shape
    with pytest.raises(ValueError, match="for each snapshot"):
        n_5bus_7sn.add(
            "Load",
            "load_1_a",
            p_set=p_set[1:],
        )


@pytest.mark.parametrize("slicer", [slice(0, 1), slice(None, None)])
def test_add_varying_multiple(n_5bus_7sn, slicer):
    buses = n_5bus_7sn.c.buses.static.index[slicer]

    # Add load component at every bus with time-dependent attribute p_set.
    load_names = "load_" + buses
    p_set = rng.random(size=(len(n_5bus_7sn.snapshots), len(buses)))
    n_5bus_7sn.add(
        "Load",
        load_names,
        bus=buses,
        p_set=p_set,
    )

    assert len(n_5bus_7sn.c.loads.static) == len(load_names)
    assert n_5bus_7sn.c.loads.static.index.name == "name"
    assert n_5bus_7sn.c.loads.static.index.equals(load_names)
    assert (n_5bus_7sn.c.loads.static.bus == buses).all()
    assert (n_5bus_7sn.c.loads.dynamic.p_set == p_set).all().all()
    assert (
        n_5bus_7sn.c.loads.static.p_set == 0
    ).all()  # Assert that default value is set

    if len(buses) > 1:
        # Test different names shape
        with pytest.raises(ValueError, match="but expected"):
            n_5bus_7sn.add("Load", load_names[1:] + "_a", p_set=p_set)

    # Test different snapshots shape
    with pytest.raises(ValueError, match="but expected"):
        n_5bus_7sn.add("Load", load_names + "_c", p_set=p_set[1:])


def test_add_varying_multiple_with_index(n_5bus_7sn):
    buses = n_5bus_7sn.c.buses.static.index

    # Add load component at every bus with time-dependent attribute p_set.
    load_names = "load_" + buses
    p_set = pd.DataFrame(
        rng.random(size=(len(n_5bus_7sn.snapshots), len(buses))),
        index=n_5bus_7sn.snapshots,
        columns=load_names,
    )

    n_5bus_7sn.add(
        "Load",
        load_names,
        bus=buses,
        p_set=p_set,
    )

    assert len(n_5bus_7sn.c.loads.static) == len(load_names)
    assert n_5bus_7sn.c.loads.static.index.name == "name"
    assert n_5bus_7sn.c.loads.static.index.equals(load_names)
    assert (n_5bus_7sn.c.loads.static.bus == buses).all()
    assert (n_5bus_7sn.c.loads.dynamic.p_set == p_set).all().all()
    assert (
        n_5bus_7sn.c.loads.static.p_set == 0
    ).all()  # Assert that default value is set

    # Test different names shape
    with pytest.raises(ValueError, match="columns which do not align"):
        n_5bus_7sn.add("Load", load_names[1:] + "_a", p_set=p_set)

    # Test unaligned names index
    with pytest.raises(ValueError, match="columns which do not align"):
        n_5bus_7sn.add("Load", load_names + "_b", p_set=swap_df_index(p_set))

    # Test different snapshots shape
    with pytest.raises(ValueError, match="index which does not align"):
        n_5bus_7sn.add("Load", load_names + "_c", p_set=p_set[1:])

    # Test different snapshots index
    with pytest.raises(ValueError, match="columns which do not align"):
        n_5bus_7sn.add("Load", load_names + "_d", p_set=swap_df_index(p_set, axis=1))


def test_add_overwrite_static(n_5bus, caplog):
    n_5bus.add("Bus", [f"bus_{i} " for i in range(6)], x=1)

    assert (n_5bus.c.buses.static.iloc[:5].x == 0).all()
    assert (n_5bus.c.buses.static.iloc[5].x == 1).all()
    assert caplog.records[-1].levelname == "WARNING"

    n_5bus.add("Bus", [f"bus_{i} " for i in range(5)], x=1, overwrite=True)
    assert (n_5bus.c.buses.static.x == 1).all()


def test_add_overwrite_varying(n_5bus_7sn, caplog):
    bus_names = [f"bus_{i} " for i in range(6)]

    n_5bus_7sn.add("Bus", bus_names, p=[1] * 6)
    assert (n_5bus_7sn.c.buses.dynamic.p.iloc[:, :5] == 0).all().all()
    assert (n_5bus_7sn.c.buses.dynamic.p.iloc[:, 5] == 1).all().all()
    assert caplog.records[-1].levelname == "WARNING"

    n_5bus_7sn.add("Bus", bus_names[:5], p=[2] * 5, overwrite=True)
    assert (n_5bus_7sn.c.buses.dynamic.p.loc[:, bus_names[:5]] == 2).all().all()
    assert (n_5bus_7sn.c.buses.dynamic.p.loc[:, bus_names[5]] == 1).all().all()

    p = rng.random(size=(7, 5))
    n_5bus_7sn.add("Bus", bus_names[:5], p=p, overwrite=False)
    assert (n_5bus_7sn.c.buses.dynamic.p.loc[:, bus_names[:5]] == 2).all().all()
    n_5bus_7sn.add("Bus", bus_names[:5], p=p, overwrite=True)
    assert (n_5bus_7sn.c.buses.dynamic.p.loc[:, bus_names[:5]] == p).all().all()


def test_add_overwrite_clears_stale_dynamic():
    """Regression for #1628: overwrite=True must clear pre-existing dynamic
    columns even if the new call does not re-supply them.
    """
    n = pypsa.Network(snapshots=range(3))
    n.add("Bus", "b")
    n.add("Generator", "g", bus="b", marginal_cost=[10.0, 20.0, 30.0])
    assert "g" in n.c.generators.dynamic.marginal_cost.columns

    n.add("Generator", "g", bus="b", marginal_cost=5.0, overwrite=True)
    assert "g" not in n.c.generators.dynamic.marginal_cost.columns


def test_add_stochastic():
    """Test adding components to stochastic networks."""
    n = pypsa.Network(snapshots=range(5))
    n.add("Bus", "bus_1", v_mag_pu_set=0.1)
    n.add("Bus", "bus_2", v_mag_pu_set=0.1)

    # Test 1: Reject MultiIndex names before scenarios
    multi_indexed = pd.MultiIndex.from_product(
        [["bus_3", "bus_4"], ["scenario_1", "scenario_2"]]
    )
    with pytest.raises(TypeError, match="Component names must be one-dimensional"):
        n.add("Bus", multi_indexed, v_mag_pu_set=0.1)

    # Set scenarios
    n.set_scenarios(["scenario_1", "scenario_2"])

    # Test 2: Reject MultiIndex names after scenarios
    with pytest.raises(
        TypeError,
        match="Component names must be one-dimensional.*broadcast",
    ):
        n.add("Bus", multi_indexed, v_mag_pu_set=0.1)

    # Test 3: Add single component with static attributes - should broadcast
    n.add("Load", "load1", bus="bus_1", p_set=50)
    assert isinstance(n.c.loads.static.index, pd.MultiIndex)
    assert n.c.loads.static.index.names == ["scenario", "name"]
    assert len(n.c.loads.static.index) == 2  # One per scenario
    assert ("scenario_1", "load1") in n.c.loads.static.index
    assert ("scenario_2", "load1") in n.c.loads.static.index
    assert n.c.loads.static.loc[("scenario_1", "load1"), "p_set"] == 50.0

    # Test 4: Add multiple components - should broadcast
    n.add("Load", ["load2", "load3"], bus=["bus_1", "bus_2"], p_set=[75, 100])
    assert len(n.c.loads.static.index) == 6  # 3 loads × 2 scenarios

    # Test 5: Add with time-varying attributes - should broadcast
    load_profile = [100, 120, 110, 130, 115]
    n.add("Load", "load4", bus="bus_2", p_set=load_profile)
    assert isinstance(n.c.loads.dynamic.p_set.columns, pd.MultiIndex)
    assert n.c.loads.dynamic.p_set.columns.names == ["scenario", "name"]
    for scenario in n.scenarios:
        assert list(n.c.loads.dynamic.p_set.loc[:, (scenario, "load4")]) == load_profile

    # Test 6: Verify can modify per scenario after adding
    n.c.loads.static.loc[("scenario_1", "load1"), "p_set"] = 80
    n.c.loads.static.loc[("scenario_2", "load1"), "p_set"] = 120
    assert n.c.loads.static.loc[("scenario_1", "load1"), "p_set"] == 80.0
    assert n.c.loads.static.loc[("scenario_2", "load1"), "p_set"] == 120.0


def test_multiple_add_defaults(n_5bus):
    """
    GIVEN   an empty PyPSA network with 5 buses.

    WHEN    adding multiple components of Generator and Load with add

    THEN    the defaults should be set correctly according to
    n.default_component_attrs.
    """
    gen_names = ["g_1", "g_2"]
    n_5bus.add(
        "Generator",
        gen_names,
        bus=["bus_1", "bus_2"],
    )

    line_names = ["l_1", "l_2"]
    n_5bus.add(
        "Load",
        line_names,
        bus=["bus_1", "bus_2"],
    )

    # TODO: Improve tests since component is the same now
    assert (
        n_5bus.c.generators.static.loc[gen_names[0], "control"]
        == n_5bus.components.Generator.defaults.loc["control", "default"]
    )

    assert (
        n_5bus.c.loads.static.loc[line_names[0], "p_set"]
        == n_5bus.components.Load.defaults.loc["p_set", "default"]
    )


def test_add_return_names():
    """Test that return_names parameter controls return behavior."""
    n = pypsa.Network()

    # Default behavior - should return None
    assert n.add("Bus", "bus1") is None
    assert n.add("Bus", "bus2", return_names=False) is None

    # With return_names=True - should return Index
    result = n.add("Bus", "bus3", return_names=True)
    assert isinstance(result, pd.Index)
    assert result[0] == "bus3"

    # Multiple components
    result = n.add("Bus", ["bus4", "bus5"], return_names=True)
    assert len(result) == 2
    assert all(name in result for name in ["bus4", "bus5"])

    # Component method
    assert n.components.buses.add("bus6") is None
    result = n.components.buses.add("bus7", return_names=True)
    assert isinstance(result, pd.Index)
    assert result[0] == "bus7"


def test_add_remove_list_suffix(n_5bus):
    # A list `suffix` with a scalar `name` builds one component per suffix (#1650).
    names = n_5bus.add(
        "Generator", "g", suffix=[" wind", " solar"], bus="bus_0 ", return_names=True
    )
    assert list(names) == ["g wind", "g solar"]
    assert list(n_5bus.c.generators.static.index) == ["g wind", "g solar"]

    n_5bus.remove("Generator", "g", suffix=[" wind", " solar"])
    assert n_5bus.c.generators.static.empty


@pytest.mark.parametrize("method", ["add", "remove"])
@pytest.mark.parametrize(
    ("name", "suffix", "match"),
    [
        # Was a silent one-by-one pairing before #1650, now rejected.
        (["a", "b"], [" wind", " solar"], "Cannot pass list to both"),
        ("g", [], "Empty list `suffix`"),
    ],
)
def test_list_suffix_invalid_raises(n_5bus, method, name, suffix, match):
    with pytest.raises(ValueError, match=match):
        getattr(n_5bus, method)("Generator", name, suffix=suffix)


@pytest.mark.parametrize(
    "p_nom",
    [
        pd.Series([100.0, 200.0], index=["g wind", "g solar"]),  # post-suffix index
        [100.0, 200.0],  # plain list, positional
    ],
)
def test_add_list_suffix_static_kwarg(n_5bus, p_nom):
    # Regression for the TypeError from str.endswith(list) on a Series kwarg (#1650).
    n_5bus.add("Generator", "g", suffix=[" wind", " solar"], bus="bus_0 ", p_nom=p_nom)
    static = n_5bus.c.generators.static
    assert static.p_nom.loc["g wind"] == 100.0
    assert static.p_nom.loc["g solar"] == 200.0


def test_add_list_suffix_dataframe_kwarg(n_5bus_7sn):
    # A DataFrame kwarg with post-suffix columns stays time-varying (#1650).
    p_max_pu = pd.DataFrame(
        rng.random((len(n_5bus_7sn.snapshots), 2)),
        index=n_5bus_7sn.snapshots,
        columns=["g wind", "g solar"],
    )
    n_5bus_7sn.add(
        "Generator", "g", suffix=[" wind", " solar"], bus="bus_0 ", p_max_pu=p_max_pu
    )
    pd.testing.assert_frame_equal(
        n_5bus_7sn.c.generators.dynamic.p_max_pu,
        p_max_pu,
        check_names=False,
        check_column_type=False,
    )


def test_add_list_suffix_misaligned_kwarg_raises(n_5bus):
    # For a list suffix the Series index must be the full post-suffix names.
    p_nom = pd.Series([100.0, 200.0], index=["g", "g"])
    with pytest.raises(ValueError, match="does not align"):
        n_5bus.add(
            "Generator", "g", suffix=[" wind", " solar"], bus="bus_0 ", p_nom=p_nom
        )


def test_multiport_assignment_defaults_single_add():
    """
    Add a single link to a network, then add a second link with additional
    ports.

    Check that the default values are assigned to the first link.
    """
    n = pypsa.Network()
    n.add("Bus", "bus")
    n.add("Bus", "bus2")
    n.add("Link", "link", bus0="bus", bus1="bus2")
    n.add("Link", "link2", bus0="bus", bus1="bus2", bus2="bus")
    assert n.c.links.static.loc["link", "bus2"] == ""


def test_multiport_assignment_defaults_multiple_add():
    """
    Add a single link to a network, then add a second link with additional
    ports.

    Check that the default values are assigned to the first link.
    """
    n = pypsa.Network()
    n.add("Bus", "bus")
    n.add("Bus", "bus2")
    n.add("Link", ["link"], bus0="bus", bus1="bus2")
    n.add("Link", ["link2"], bus0="bus", bus1="bus2", bus2="bus")
    assert n.c.links.static.loc["link", "bus2"] == ""


def test_331():
    """
    See https://github.com/PyPSA/PyPSA/issues/331.
    """
    n = pypsa.Network()
    n.add("Bus", "bus")
    n.add("Load", "load", bus="bus", p_set=10)
    n.add("Generator", "generator1", bus="bus", p_nom=15, marginal_cost=10)
    n.optimize()
    n.add("Generator", "generator2", bus="bus", p_nom=5, marginal_cost=5)
    n.optimize()
    assert "generator2" in n.c.generators.dynamic.p


@pytest.mark.skipif(
    sys.platform == "win32",
    reason="pd.equals fails on windows (https://stackoverflow.com/questions/62128721).",
)
def test_equality_behavior(networks):
    """
    GIVEN   the AC DC exemplary pypsa network.

    WHEN    comparing the network to itself

    THEN    the networks should be equal.
    """
    n = networks
    deep_copy = copy.deepcopy(n)
    assert n is not deep_copy
    assert n.equals(deep_copy, log_mode="strict")

    assert n == deep_copy

    # TODO: Could add more property based tests here (hypothesis)
    deep_copy.name = "new_name"
    assert n != deep_copy

    assert n != "other_type"


@pytest.mark.skipif(
    sys.platform == "win32",
    reason="pd.equals fails on windows (https://stackoverflow.com/questions/62128721).",
)
def test_copy_default_behavior(networks):
    """
    GIVEN   the AC DC exemplary pypsa network.

    WHEN    copying the network with timestamps

    THEN    the copied network should have the same generators, loads
    and timestamps.
    """
    n = networks
    network_copy = n.copy()
    assert n == network_copy
    assert n is not network_copy


COPY_METHODS = {
    "copy": lambda n: n.copy(),
    "deepcopy": copy.deepcopy,
    "pickle": lambda n: pickle.loads(pickle.dumps(n)),
    "copy_snapshots": lambda n: n.copy(snapshots=n.snapshots[:3]),
}


@pytest.mark.parametrize(
    ("network", "method"),
    [
        (network, method)
        for network in ["ac_dc_network", "ac_dc_stochastic"]
        for method in COPY_METHODS
        if not (network == "ac_dc_stochastic" and method == "copy_snapshots")
    ],
)
def test_copy_relinks_sub_networks(request, network, method):
    """
    Copies own SubNetwork objects linked to the copy, the original stays linked.
    See https://github.com/PyPSA/PyPSA/issues/1888 and #1930.
    """
    n = request.getfixturevalue(network)
    n.determine_network_topology()
    n_copy = COPY_METHODS[method](n)
    subs = n.c.sub_networks.static.obj
    subs_copy = n_copy.c.sub_networks.static.obj
    assert len(subs) > 0
    assert subs_copy.index.equals(subs.index)
    for sub, sub_copy in zip(subs, subs_copy, strict=True):
        assert sub is not sub_copy
        assert sub.n is n
        assert sub_copy.n is n_copy
    assert n.equals(n_copy) == (method != "copy_snapshots")


@pytest.mark.parametrize("network", ["ac_dc_network", "ac_dc_stochastic"])
def test_equals_skips_sub_networks(request, network):
    """Networks differ in topology columns and component data, not in SubNetworks."""
    n = request.getfixturevalue(network)
    n_without_topology = n.copy()
    n.determine_network_topology()
    n_other_lines = n.copy()
    n_other_lines.c.lines.static["x"] *= 2
    assert not n.equals(n_without_topology)
    assert not n.equals(n_other_lines)


def test_shallow_copy_keeps_original_sub_networks(ac_dc_network):
    """copy.copy shares SubNetwork objects and leaves them linked to the original."""
    n = ac_dc_network
    n.determine_network_topology()
    copy.copy(n)
    assert all(sub.n is n for sub in n.c.sub_networks.static.obj)


@pytest.mark.parametrize("copy_method", COPY_METHODS.values(), ids=COPY_METHODS)
def test_copy_keeps_snapshot_names(ac_dc_periods, copy_method):
    """Copies keep the name of multi-indexed snapshots, see #1937."""
    n_copy = copy_method(ac_dc_periods)
    assert n_copy.snapshots.name == "snapshot"
    assert n_copy.snapshot_weightings.index.name == "snapshot"
    assert n_copy.c.generators.dynamic.p.index.name == "snapshot"
    assert n_copy.c.generators.da.p_max_pu.dims == ("snapshot", "name")


@pytest.mark.parametrize(
    ("kwargs", "period"),
    [
        ({"snapshots": pd.MultiIndex.from_product([[2030], range(2)])}, 2030),
        ({"investment_periods": [2020]}, 2020),
    ],
)
def test_copy_selects_investment_periods(kwargs, period):
    """Selecting snapshots or investment periods on copy selects the other."""
    n = pypsa.Network()
    n.snapshots = pd.MultiIndex.from_product([[2020, 2030], range(2)])
    n.investment_periods = [2020, 2030]
    n.add("Bus", "bus")
    n.add("Generator", "gen", bus="bus", p_nom=10, marginal_cost=1)
    n.add("Load", "load", bus="bus", p_set=5)
    n_copy = n.copy(**kwargs)
    assert n_copy.investment_periods.tolist() == [period]
    assert n_copy.snapshots.unique("period").tolist() == [period]
    status, _ = n_copy.optimize(multi_investment_periods=True)
    assert status == "ok"


def test_copy_snapshots_keeps_crs(ac_dc_network):
    """Selective copies keep a non-default coordinate reference system."""
    n = ac_dc_network
    n.to_crs(3035)
    n_copy = n.copy(snapshots=n.snapshots[:3])
    assert n_copy.crs == n.crs
    assert n_copy.c.buses.static.x.equals(n.c.buses.static.x)


def test_copy_with_model(ac_dc_network):
    n = ac_dc_network
    n.optimize.create_model()
    n_copy = n.copy()

    assert n.equals(n_copy, log_mode="strict")
    assert isinstance(n.model, linopy.Model)
    assert isinstance(n_copy.model, linopy.Model)

    n.optimize.solve_model()
    with pytest.raises(
        ValueError,
        match="Copying a solved network with an attached solver model is not supported.",
    ):
        n_copy = n.copy()

    n.optimize()
    with pytest.raises(
        ValueError,
        match="Copying a solved network with an attached solver model is not supported.",
    ):
        n_copy = n.copy()


def test_1319():
    """
    Copying a solved network should work after setting solver_model to None.
    See https://github.com/PyPSA/PyPSA/issues/1319.
    """
    n = pypsa.examples.ac_dc_meshed()
    n.optimize()

    # Should raise error when trying to copy with solver_model attached
    with pytest.raises(
        ValueError, match="Copying a solved network with an attached solver model"
    ):
        n.copy()

    # Should work after setting solver_model to None
    n.model.solver_model = None
    n_copy = n.copy()  # Should not raise an error
    assert n_copy is not n
    assert len(n_copy.buses) == len(n.c.buses.static)


def test_1420(tmp_path):
    """
    Network pickling should not cause RecursionError in xarray accessor.
    See https://github.com/PyPSA/PyPSA/issues/1420.
    """
    n = pypsa.Network()
    n.add("Bus", "bus")
    n.add("Generator", "gen", bus="bus", p_nom=100)

    pickle_file = tmp_path / "network.pkl"

    with Path(pickle_file).open("wb") as out:
        pickle.dump(n, out)

    with Path(pickle_file).open("rb") as inp:
        n_loaded = pickle.load(inp)

    # Verify network was loaded correctly
    assert len(n_loaded.c.buses.static) == 1
    assert len(n_loaded.c.generators.static) == 1
    # tmp_path is automatically cleaned up by pytest


@pytest.mark.skipif(
    sys.platform == "win32",
    reason="pd.equals fails on windows (https://stackoverflow.com/questions/62128721).",
)
def test_copy_snapshots(networks):
    """
    GIVEN   the AC DC exemplary pypsa network.

    WHEN    copying the network without snapshots

    THEN    the copied network should only have the current time index.
    """
    n = networks

    if n.has_scenarios:
        with pytest.raises(
            NotImplementedError,
            match="Copying a stochastic network with a selection is currently not supported.",
        ):
            n.copy(snapshots=n.snapshots[:5])

        return

    copied_n = n.copy(snapshots=[])
    assert copied_n.snapshots.size == 1

    copied_n = n.copy(snapshots=n.snapshots[:5])
    n.set_snapshots(n.snapshots[:5])
    assert copied_n == n


def test_single_add_network_static(ac_dc_network, n_5bus):
    """
    GIVEN   the AC DC exemplary pypsa network and an empty PyPSA network with 5
    buses.

    WHEN    the second network is added to the first

    THEN    the first network should now contain its original buses and
    also the buses in the second network
    """
    n = ac_dc_network.merge(n_5bus, with_time=False)
    new_buses = set(n.c.buses.static.index)
    assert new_buses.issuperset(n_5bus.c.buses.static.index)


def test_single_add_network_with_time(ac_dc_network, n_5bus):
    """
    GIVEN   the AC DC exemplary pypsa network and an empty PyPSA network with 5
    buses and the same snapshots.

    WHEN    the second network is added to the first

    THEN    the first network should now contain its original buses and
    also the buses in the second network
    """
    with pytest.raises(ValueError):
        ac_dc_network.merge(n_5bus, with_time=True)

    n_5bus.set_snapshots(ac_dc_network.snapshots)
    n = ac_dc_network.merge(n_5bus, with_time=True)
    new_buses = set(n.c.buses.static.index)
    assert new_buses.issuperset(n_5bus.c.buses.static.index)


def test_shape_reprojection(ac_dc_shapes):
    n = ac_dc_shapes

    with pytest.warns(UserWarning):  # noqa
        area_before = n.c.shapes.static.geometry.area.sum()
    x, y = n.c.buses.static.x.values, n.c.buses.static.y.values

    n.to_crs("epsg:3035")

    assert n.c.shapes.static.crs == "epsg:3035"
    assert n.crs == "epsg:3035"
    assert area_before != n.c.shapes.static.geometry.area.sum()
    assert not np.allclose(x, n.c.buses.static.x.values)
    assert not np.allclose(y, n.c.buses.static.y.values)


def test_components_referencing(ac_dc_network):
    with pypsa.option_context("api.new_components_api", False):
        ac_dc_network = pypsa.examples.ac_dc_meshed()
        assert id(ac_dc_network.buses) == id(ac_dc_network.components.buses.static)
        assert id(ac_dc_network.c.buses.dynamic) == id(
            ac_dc_network.components.buses.dynamic
        )
        assert id(ac_dc_network.components.buses) == id(ac_dc_network.components.Bus)


@pytest.mark.parametrize("use_component", [True, False])
def test_rename_component_names(use_component):
    n = pypsa.Network()
    n.snapshots = [0, 1]

    n.add("Bus", "bus1", v_mag_pu_set=[0.1, 0.2])
    n.add("Bus", "bus2", v_mag_pu_set=[0.1, 0.2])
    n.add("Line", "line1", bus0="bus1", bus1="bus2", s_max_pu=[0.1, 0.2])
    n.add("Generator", "gen1", bus="bus1", p_min_pu=[0.1, 0.2])

    if use_component:
        c = n.c.buses
        c.rename_component_names(bus1="bus3")
    else:
        n.rename_component_names("Bus", bus1="bus3")

    with pytest.raises(ValueError):
        n.rename_component_names("Bus", bus1=10)

    assert "bus1" not in n.c.buses.static.index
    assert "bus1" not in n.c.buses.dynamic.v_mag_pu_set.columns
    assert "bus2" in n.c.buses.static.index
    assert "bus2" in n.c.buses.dynamic.v_mag_pu_set.columns
    assert "bus3" in n.c.buses.static.index
    assert "bus3" in n.c.buses.dynamic.v_mag_pu_set.columns

    assert "bus1" not in n.c.lines.static.bus0.to_list()
    assert "bus1" not in n.c.lines.static.bus1.to_list()
    assert "bus3" in n.c.lines.static.bus0.to_list()
    assert "bus2" in n.c.lines.static.bus1.to_list()

    assert "bus1" not in n.c.generators.static.bus.to_list()
    assert "bus3" in n.c.generators.static.bus.to_list()


def test_components_repr(ac_dc_network):
    n = ac_dc_network

    assert repr(n).startswith("PyPSA Network 'AC-DC-Meshed'")
    assert len(repr(n)) > len(str(n))

    n = pypsa.Network()
    assert repr(n).startswith("Empty PyPSA Network 'Unnamed Network'")
    assert len(repr(n)) > len(str(n))


@pytest.mark.parametrize("new_components_api", [True, False])
def test_api_components_legacy(new_components_api):
    """
    Test the API of the components module.
    """
    with pypsa.option_context("api.new_components_api", new_components_api):
        n = pypsa.examples.ac_dc_meshed()

        if not new_components_api:
            assert n.buses is n.components.buses.static
            assert n.c.buses.dynamic is n.components.buses.dynamic
            assert n.lines is n.components.lines.static
            assert n.c.lines.dynamic is n.components.lines.dynamic
            assert n.generators is n.components.generators.static
            assert n.c.generators.dynamic is n.components.generators.dynamic
        else:
            assert n.buses is n.components.buses
            with pytest.warns(
                DeprecationWarning, match=r"Use `n\.buses\.dynamic` as a drop-in"
            ):
                assert n.buses_t is n.components.buses.dynamic
            assert n.lines is n.components.lines
            with pytest.warns(
                DeprecationWarning, match=r"Use `n\.lines\.dynamic` as a drop-in"
            ):
                assert n.lines_t is n.components.lines.dynamic
            assert n.generators is n.components.generators
            with pytest.warns(
                DeprecationWarning, match=r"Use `n\.generators\.dynamic` as a drop-in"
            ):
                assert n.generators_t is n.components.generators.dynamic


@pytest.mark.parametrize("new_components_api", [True, False])
def test_api_new_components_api(component_name, new_components_api):
    """
    Test the API of the components module.
    """
    warnings.filterwarnings(
        "ignore",
        message=".*is deprecated as of 1.0 and will be .*",
        category=DeprecationWarning,
    )
    with pypsa.option_context("api.new_components_api", new_components_api):
        n = pypsa.examples.ac_dc_meshed()
        if not new_components_api:
            with pytest.warns(
                DeprecationWarning,
                match="Use `self.components.<component>.static` instead.",
            ):
                assert n.static(component_name) is n.c[component_name].static
            with pytest.warns(
                DeprecationWarning,
                match="Use `self.components.<component>.dynamic` instead.",
            ):
                assert n.dynamic(component_name) is n.c[component_name].dynamic

            setattr(n, component_name, "test")
            with pytest.warns(
                DeprecationWarning,
                match="Use `self.components.<component>.static` instead.",
            ):
                assert n.static(component_name) == "test"
            setattr(n, f"{component_name}_t", "test")
            with pytest.warns(
                DeprecationWarning,
                match="Use `self.components.<component>.dynamic` instead.",
            ):
                assert n.dynamic(component_name) == "test"
        else:
            with pytest.warns(
                DeprecationWarning,
                match="Use `self.components.<component>.static` instead.",
            ):
                assert n.static(component_name) is n.c[component_name].static
            with pytest.warns(
                DeprecationWarning,
                match="Use `self.components.<component>.dynamic` instead.",
            ):
                assert n.dynamic(component_name) is n.c[component_name].dynamic
            with pytest.raises(AttributeError):
                setattr(n, component_name, "test")
            with pytest.warns(DeprecationWarning, match="cannot be set"):
                setattr(n, f"{component_name}_t", "test")


def test_sanitize():
    """Test sanitize method adds missing buses, carriers, and colors."""
    n = pypsa.Network()
    # Add components with missing buses and carriers
    n.add("Generator", "gen1", bus="missing_bus", carrier="missing_carrier", p_nom=100)
    n.add("Load", "load1", bus="missing_bus2", carrier="electricity", p_set=50)

    # Before sanitize
    assert len(n.c.buses.static) == 0
    assert len(n.c.carriers.static) == 0

    n.sanitize()

    # After sanitize - buses should be added
    assert "missing_bus" in n.c.buses.names
    assert "missing_bus2" in n.c.buses.names

    # After sanitize - carriers should be added (including AC from buses)
    assert "missing_carrier" in n.c.carriers.names
    assert "electricity" in n.c.carriers.names

    # After sanitize - carriers should have colors assigned
    assert n.c.carriers.static.loc["missing_carrier", "color"] != ""
    assert n.c.carriers.static.loc["electricity", "color"] != ""


def test_sanitize_with_existing_data():
    """Test sanitize doesn't overwrite existing data."""
    n = pypsa.Network()
    n.add("Bus", "bus1", v_nom=110)
    n.add("Carrier", "wind", color="blue", co2_emissions=0.0)
    n.add("Generator", "gen1", bus="bus1", carrier="wind", p_nom=100)
    n.add("Generator", "gen2", bus="bus2", carrier="solar", p_nom=200)

    n.sanitize()

    # Existing bus unchanged
    assert n.c.buses.static.loc["bus1", "v_nom"] == 110
    # New bus added
    assert "bus2" in n.c.buses.names

    # Existing carrier color unchanged
    assert n.c.carriers.static.loc["wind", "color"] == "blue"
    # New carrier has color assigned
    assert n.c.carriers.static.loc["solar", "color"] != ""


def test_sanitize_no_changes_needed():
    """Test sanitize works when no changes are needed."""
    n = pypsa.Network()
    n.add("Bus", "bus1")
    n.add("Carrier", "wind", color="#1f77b4")
    n.add("Generator", "gen1", bus="bus1", carrier="wind", p_nom=100)

    # No missing data
    n.sanitize()

    # Should still work without errors
    assert len(n.c.buses.static) == 1
    assert len(n.c.carriers.static) == 2  # wind + AC from bus

    # Stochastic network
    n2 = pypsa.Network()
    n2.add("Bus", "bus1")
    n2.set_scenarios(["s1", "s2"])
    n2.add("Generator", "gen1", bus="missing_bus", carrier="missing_carrier", p_nom=100)
    n2.sanitize()
    assert ("s1", "missing_bus") in n2.c.buses.static.index
    assert ("s1", "missing_carrier") in n2.c.carriers.static.index
